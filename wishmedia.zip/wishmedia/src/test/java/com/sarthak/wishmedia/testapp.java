package com.sarthak.wishmedia;

import org.junit.Test;

import junit.framework.TestCase;

public class testapp extends TestCase {
@Test
public void testevenodd()
{
	
App a=new App();
a.evenodd(2);
a.evenodd(3);




}
}
